package http.prefab.guiElement;

import java.lang.reflect.Field;

public abstract class FieldGuiElement extends GuiElement {


	Field field;

	public FieldGuiElement(String name) {
		super(name);
	}

	@Override
	public String preDefBuild() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String build(String addTo, String objectName) {
		// TODO Auto-generated method stub
		return null;
	}

}
