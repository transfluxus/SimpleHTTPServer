package http.prefab.test;

public class TestClass2 {

	//public int[] vals = {0,5,10,20}; 
	public String[] vals = {"Stroke","Fill","StrokeFill"};
	public String value;	
}
