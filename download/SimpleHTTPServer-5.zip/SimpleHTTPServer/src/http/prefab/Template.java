package http.prefab;

public class Template {

}
